function isHasImg(pathImg) {
  if (!pathImg) return false;
  try {
    var xmlHttp = null;
    if (window.XMLHttpRequest) {
      xmlHttp = new XMLHttpRequest();
    }
    xmlHttp.open("Get", pathImg, false);
    xmlHttp.send();
    if (xmlHttp.status == 200) return true;
    else return false;
  } catch (error) {
    return false;
  }
}
function getParams(name) {
  if (name === undefined) {
    let url = location.href;
    let regx = /([^&?=]+)=([^&?=]+)/g;
    let obj = {};
    url.replace(regx, (...args) => {
      if (obj[args[1]]) {
        obj[args[1]] = Array.isArray(obj[args[1]])
          ? obj[args[1]]
          : [obj[args[1]]];
        obj[args[1]].push(args[2]);
      } else {
        obj[args[1]] = args[2];
      }
    });

    return obj;
  }
  return new URLSearchParams(location.search).get(name);
}
function setParams(name, value, url = "") {
  const params = new URLSearchParams(location.search);
  if (value instanceof Array) {
    value.forEach(({ key, value }) => {
      params.set(key, value);
    });
  } else {
    params.set(name, value);
  }

  params.set("page", 1);
  if (url) {
    location.href = url + "?" + params.toString();
  } else {
    location.search = params.toString();
  }
}
function removeParams(name) {
  console.log(name);
  const params = new URLSearchParams(location.search);
  params.delete(name);
  location.search = params.toString();
}

function setVisitLocation(cvalue, exdays) {
  let ha = false;
  let sb = getVisitLocation();
  sb.forEach((item) => {
    if (
      item.name == cvalue.name &&
      item.tag == cvalue.tag &&
      item.url == cvalue.url
    );

  });
  for (var i = 0; i < sb.length; i++) {
    if (sb[i].name === cvalue.name) {
      sb.splice(i, 1);
    }
  }
  if (!ha) {
    sb.unshift(cvalue);
    if (sb.length > 10) {
      sb = sb.splice(0, 10);
    }
  }
  let str = JSON.stringify(sb);
  localStorage.setItem("visit", str);
}
function getVisitLocation() {
  let tmp = localStorage.getItem("visit");
  return JSON.parse(tmp || "[]") || [];
}

function delVisitLocation() {
  localStorage.removeItem("visit");
}

// 搜索历史
function setHistoryLocation(cvalue, exdays) {
  let ha = false;
  let sb = getHistoryLocation();
  sb.forEach((item) => {
    if (item.name == cvalue.name && item.url == cvalue.url) ha = true;
  });
  if (!ha) {
    sb.unshift(cvalue);
    if (sb.length > 10) {
      sb = sb.splice(0, 10);
    }
  }
  let str = JSON.stringify(sb);
  localStorage.setItem("searchHistory", str);
}
function getHistoryLocation() {
  let tmp = localStorage.getItem("searchHistory");
  return JSON.parse(tmp || "[]") || [];
}

function delHistoryLocation() {
  localStorage.removeItem("searchHistory");
}
