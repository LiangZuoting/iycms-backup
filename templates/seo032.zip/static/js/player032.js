

function show_history(cookie_name) {
  var history = $.cookie("mac_history_mxpro");
  var history_data = [];
  var history_html = "";
  if (history != undefined && history != "") {
    history_data = eval(history);
  }
  if (history_data.length > 0) {
    for (var $i = 0; $i < history_data.length; $i++) {
      history_html +=
        '<li class="drop-item drop-item-content"><a href="' +
        history_data[$i].vod_url +
        '" title="' +
        history_data[$i].vod_name +
        '" class="drop-item-link"><span>' +
        history_data[$i].vod_part +
        "</span>" +
        history_data[$i].vod_name +
        "</a></li>";
      historyclean_html =
        '<li class="drop-item-op"><a href="" class="historyclean">清空</a></li>>';
    }
  } else {
    // history_html =
    //   '<li class="drop-item drop-item-content nolist"><div class="drop-prompt">暂无观看影片的记录</div></li>';
  }
  $(".historical").append(history_html);
  try {
    $(".historical").append(historyclean_html);
  } catch (e) {}
}


